<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class products extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('products_model','products');
	}

	public function index()
	{
		$this->load->helper('url');
		$this->load->view('products_view');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->products->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $products) {
			$no++;
			$row = array();
			$row[] = $products->product_name;
			$row[] = $products->product_price;
			$row[] = $products->product_description;
			if($products->product_image)
				$row[] = '<a href="'.base_url('upload/'.$products->product_image).'" target="_blank"><img src="'.base_url('upload/'.$products->product_image).'" class="img-responsive" /></a>';
			else
				$row[] = '(No product_image)';

			//add html for action
			$row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_products('."'".$products->id."'".')"><i class="glyphicon glyphicon-pencil"></i> Edit</a>
				  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_products('."'".$products->id."'".')"><i class="glyphicon glyphicon-trash"></i> Delete</a>';
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->products->count_all(),
						"recordsFiltered" => $this->products->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	public function ajax_edit($id)
	{
		$data = $this->products->get_by_id($id);
		
		echo json_encode($data);
	}

	public function ajax_add()
	{
		$this->_validate();
		
		$data = array(
				'product_name' => $this->input->post('product_name'),
				'product_price' => $this->input->post('product_price'),
				'product_description' => $this->input->post('product_description'),
			);

		if(!empty($_FILES['product_image']['name']))
		{
			$upload = $this->_do_upload();
			$data['product_image'] = $upload;
		}

		$insert = $this->products->save($data);

		echo json_encode(array("status" => TRUE));
	}

	public function ajax_update()
	{
		$this->_validate();
		$data = array(
				'product_name' => $this->input->post('product_name'),
				'product_price' => $this->input->post('product_price'),
				'product_description' => $this->input->post('product_description'),
			);

		if($this->input->post('remove_product_image')) // if remove product_image checked
		{
			if(file_exists('upload/'.$this->input->post('remove_product_image')) && $this->input->post('remove_product_image'))
				unlink('upload/'.$this->input->post('remove_product_image'));
			$data['product_image'] = '';
		}

		if(!empty($_FILES['product_image']['name']))
		{
			$upload = $this->_do_upload();
			
			//delete file
			$products = $this->products->get_by_id($this->input->post('id'));
			if(file_exists('upload/'.$products->product_image) && $products->product_image)
				unlink('upload/'.$products->product_image);

			$data['product_image'] = $upload;
		}

		$this->products->update(array('id' => $this->input->post('id')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		//delete file
		$products = $this->products->get_by_id($id);
		if(file_exists('upload/'.$products->product_image) && $products->product_image)
			unlink('upload/'.$products->product_image);
		
		$this->products->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

	private function _do_upload()
	{
		$config['upload_path']          = 'upload/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 500; //set max size allowed in Kilobyte
        $config['max_width']            = 10000; // set max width image allowed
        $config['max_height']           = 10000; // set max height allowed
        $config['file_name']            = round(microtime(true) * 1000); //just milisecond timestamp fot unique name

        $this->load->library('upload', $config);

        if(!$this->upload->do_upload('product_image')) //upload and validate
        {
            $data['inputerror'][] = 'product_image';
			$data['error_string'][] = 'Upload error: '.$this->upload->display_errors('',''); //show ajax error
			$data['status'] = FALSE;
			echo json_encode($data);
			exit();
		}
		return $this->upload->data('file_name');
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('product_name') == '')
		{
			$data['inputerror'][] = 'product_name';
			$data['error_string'][] = 'Product name is required';
			$data['status'] = FALSE;
		}

		if($this->input->post('product_price') == '')
		{
			$data['inputerror'][] = 'procuct_price';
			$data['error_string'][] = 'Product price is required';
			$data['status'] = FALSE;
		}

		if($this->input->post('product_description') == '')
		{
			$data['inputerror'][] = 'product_description';
			$data['error_string'][] = 'Product description is required';
			$data['status'] = FALSE;
		}


		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}

}
